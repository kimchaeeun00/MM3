package com.moneymate.controller;

import com.moneymate.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // 회원가입 페이지 이동
    @GetMapping("/signup")
    public String signupForm() {
        return "signup"; // templates/signup.html
    }

    // ❌ 로그인 API는 절대 여기서 처리하면 안 됨!
    // UserRestController에서 /api/user/login 을 이미 처리하고 있음.
}
