//package com.moneymate.controller;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
//
//@Controller
//public class ExpensePageController {
//
//	@GetMapping("/moneymate")
//    public String moneyMatePage() {
//        return "moneymate";  // templates/moneymate.html 실행
//    }
//}
package com.moneymate.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.moneymate.entity.User;

@Controller
public class ExpensePageController {

    @GetMapping("/moneymate")
    public String moneyMatePage(HttpSession session, Model model) {

        User user = (User) session.getAttribute("loggedInUser");

        if (user != null) {
            model.addAttribute("name", user.getName());   // ← 이름 보내기
        }

        return "moneymate";  // templates/moneymate.html
    }
}
